// client.js
//
// Runs in the browser. Talks to navigator.credentials.create()/get() via
// @simplewebauthn/browser's helpers (loaded from /vendor as the global
// `SimpleWebAuthnBrowser`), and to our own server for the two round trips
// every WebAuthn ceremony needs: "give me a challenge" then "verify what I
// signed".

const {
  startRegistration,
  startAuthentication,
  browserSupportsWebAuthn,
  platformAuthenticatorIsAvailable,
} = SimpleWebAuthnBrowser;

const usernameInput = document.getElementById('username');
const btnRegister = document.getElementById('btn-register');
const btnLogin = document.getElementById('btn-login');
const btnLogout = document.getElementById('btn-logout');
const supportNote = document.getElementById('support-note');
const logList = document.getElementById('log');
const loggedOutView = document.getElementById('logged-out-view');
const loggedInView = document.getElementById('logged-in-view');
const welcomeUsername = document.getElementById('welcome-username');

function log(message, kind = '') {
  const li = document.createElement('li');
  li.textContent = message;
  if (kind) li.className = kind;
  logList.appendChild(li);
  logList.scrollTop = logList.scrollHeight;
}

function setButtonsDisabled(disabled) {
  btnRegister.disabled = disabled;
  btnLogin.disabled = disabled;
}

function showLoggedIn(username) {
  welcomeUsername.textContent = username;
  loggedOutView.hidden = true;
  loggedInView.hidden = false;
}

function showLoggedOut() {
  loggedOutView.hidden = false;
  loggedInView.hidden = true;
}

// ---------------------------------------------------------------------------
// Startup check: does this browser/device even support a platform
// authenticator with PIN/biometric? Tell the user up front instead of
// letting the ceremony fail with a cryptic error.
// ---------------------------------------------------------------------------
(async () => {
  if (!browserSupportsWebAuthn()) {
    supportNote.textContent = 'This browser does not support WebAuthn.';
    setButtonsDisabled(true);
    return;
  }
  const available = await platformAuthenticatorIsAvailable();
  if (!available) {
    supportNote.textContent =
      'No platform authenticator detected. Set up Windows Hello, Touch ID, or a device PIN/biometric, then reload.';
  }
})();

// ---------------------------------------------------------------------------
// Registration
// ---------------------------------------------------------------------------
btnRegister.addEventListener('click', async () => {
  const username = usernameInput.value.trim();
  if (!username) return log('Enter a username first.', 'error');

  setButtonsDisabled(true);
  try {
    log(`Requesting a registration challenge for "${username}"...`);
    const optionsResp = await fetch(`/register/options?username=${encodeURIComponent(username)}`);
    if (!optionsResp.ok) throw new Error((await optionsResp.json()).error || 'Server rejected the request');
    const optionsJSON = await optionsResp.json();

    log('Challenge received. Asking your device to create a passkey — enter your PIN or use biometrics when prompted.');
    const attestationResponse = await startRegistration({ optionsJSON });

    log('Device signed the challenge with a brand-new private key. Sending the public key to the server...');
    const verifyResp = await fetch('/register/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, attestationResponse }),
    });
    const verifyJSON = await verifyResp.json();

    if (verifyJSON.verified) {
      log('Server verified the registration. Your private key never left this device.', 'success');
    } else {
      log(`Server could not verify registration: ${verifyJSON.error || 'unknown error'}`, 'error');
    }
  } catch (err) {
    log(`Registration failed: ${describeError(err)}`, 'error');
  } finally {
    setButtonsDisabled(false);
  }
});

// ---------------------------------------------------------------------------
// Login
// ---------------------------------------------------------------------------
btnLogin.addEventListener('click', async () => {
  const username = usernameInput.value.trim();
  if (!username) return log('Enter a username first.', 'error');

  setButtonsDisabled(true);
  try {
    log(`Requesting a login challenge for "${username}"...`);
    const optionsResp = await fetch(`/login/options?username=${encodeURIComponent(username)}`);
    if (!optionsResp.ok) throw new Error((await optionsResp.json()).error || 'No registered device for this user');
    const optionsJSON = await optionsResp.json();

    log('Challenge received. Asking your device to sign it — enter your PIN or use biometrics when prompted.');
    const assertionResponse = await startAuthentication({ optionsJSON });

    log('Device signed the challenge with the stored private key. Sending the signature to the server...');
    const verifyResp = await fetch('/login/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, assertionResponse }),
    });
    const verifyJSON = await verifyResp.json();

    if (verifyJSON.verified) {
      log('Signature verified against the stored public key. Access granted.', 'success');
      showLoggedIn(username);
    } else {
      log(`Login failed: ${verifyJSON.error || 'signature did not verify'}`, 'error');
    }
  } catch (err) {
    log(`Login failed: ${describeError(err)}`, 'error');
  } finally {
    setButtonsDisabled(false);
  }
});

btnLogout.addEventListener('click', () => {
  log('Logged out.');
  showLoggedOut();
});

function describeError(err) {
  if (err.name === 'NotAllowedError') {
    return 'cancelled, timed out, or user verification (PIN/biometric) was not completed.';
  }
  if (err.name === 'InvalidStateError') {
    return 'this device is already registered for this username.';
  }
  return err.message || String(err);
}
